<script>location.href = '../HomePage/sanza-template?userid=$row['uidUsers']&id=$row['idUsers']';</script>
