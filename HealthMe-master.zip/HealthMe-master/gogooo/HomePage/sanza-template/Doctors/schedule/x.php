<?php
class T{
function x()
{echo "Ahmed";}
}
 ?>
